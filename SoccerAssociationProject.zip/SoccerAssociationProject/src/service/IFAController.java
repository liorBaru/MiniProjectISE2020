package service;

public class IFAController {
}
