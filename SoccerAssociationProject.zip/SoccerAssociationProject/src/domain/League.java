package domain;

import java.util.List;
import java.util.TreeMap;

public class League
{
    private String name;
    private int level;
    private List<Refree> refrees;
    private TreeMap<Season, SeasonInfo> seasons;



}
