package domain;

public class TeamInfo
{
    private int points;
    private int goals;
    private int oGoals;
    private int losses;
    private int victories;
    private int draw;





}
