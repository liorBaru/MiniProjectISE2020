package domain;

public interface pageable
{
    void uploadDataToPage(String data);
}
