package domain;

import java.util.List;

public interface LeagueCalcolator
{
    public List <TeamInfo> calculatePoints (SeasonInfo season);
}
