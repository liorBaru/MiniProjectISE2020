package domain;

public class VarRefree extends Refree
{
    public VarRefree (String name, String training, Account account)
    {
        super(name,training,account);
    }

}
