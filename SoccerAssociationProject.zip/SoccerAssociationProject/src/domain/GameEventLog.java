package domain;

import java.util.Date;
import java.util.List;

public class GameEventLog
{
    List<Event> events;


    public boolean createEvent(TeamMember teamMember, EventType type, int minute, Date date){return false;}



}
