package domain;

import java.util.TreeMap;

public class Season
{
    private int year;
    private boolean start;
    private TreeMap<League, SeasonInfo> teams;


}
