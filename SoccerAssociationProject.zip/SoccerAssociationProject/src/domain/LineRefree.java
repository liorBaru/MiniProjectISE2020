package domain;

public class LineRefree extends Refree
{

    public LineRefree(String name, String training, Account account)
    {
        super(name,training,account);
    }
}
