package domain;

import java.util.List;
import java.util.TreeMap;

public class SeasonInfo
{
    private GameScheduale gameScheduale;
    private LeagueCalcolator leagueCalcolator;
    private TreeMap<Integer, List<Game>> games;
    private List <TeamInfo> table;



}
