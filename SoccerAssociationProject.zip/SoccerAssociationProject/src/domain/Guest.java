package domain;

public class Guest
{
    protected System system;
    public boolean login(String userName, String password){return false;}
    public boolean register(String name, String userName, String password){return false;}
    public void search (String key){}


}
